from cliente.interface.interface import Interface

def main():
    print("Executing Main inside Interface")
    inte = Interface()
    inte.execute()

if __name__ == "__main__":
    main()
