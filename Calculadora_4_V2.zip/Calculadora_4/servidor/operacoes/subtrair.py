class Subtrair:
    def __init__(self):
        self.x = 0
        self.y = 0

    def execute(self,x:float,y:float):
        self.x = x
        self.y = y
        return self.x - self.y