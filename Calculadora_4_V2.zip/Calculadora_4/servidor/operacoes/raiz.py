class RaizQuadrada:
    def __init__(self):
        self.x = 0

    def execute(self,x:float):
        self.x = x
        if self.x < 0:
            return "Error: Square root of a negative number is not defined in the real number system."
        else:
            return self.x ** 0.5
        