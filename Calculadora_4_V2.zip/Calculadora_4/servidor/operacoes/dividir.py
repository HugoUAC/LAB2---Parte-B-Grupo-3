class Dividir:
    def __init__(self):
        self.x = 0
        self.y = 0
        
    def execute(self,x:float,y:float):
        self.x = x
        self.y = y
        try:
            return self.x / self.y
        except ZeroDivisionError:
            return "Error: Division by zero is not allowed."