from servidor.maquina.maquina import Maquina

def main():
    print("Executing Main inside Server")
    maq = Maquina()
    maq.execute()

if __name__ == "__main__":
    main()
