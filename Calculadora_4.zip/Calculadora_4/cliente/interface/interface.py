import socket
import json

# =============================================================================
# CONFIGURAÇÕES DE REDE
# =============================================================================

PORT = 35000
SERVER_ADDRESS = "localhost"


# =============================================================================
# CLASSE INTERFACE — Cliente da calculadora remota
# =============================================================================

class Interface:
    """
    Interface de cliente para comunicação com o servidor de operações matemáticas.

    Estabelece uma ligação TCP com o servidor e permite ao utilizador realizar
    operações aritméticas (adição, subtração, multiplicação, divisão e raiz quadrada)
    de forma remota, enviando comandos e recebendo resultados via socket.
    """

    def __init__(self):
        """
        Inicializa os atributos da interface.

        Define os operandos e as constantes de protocolo utilizadas na comunicação
        com o servidor, incluindo tamanhos de mensagem e identificadores de operações.
        """

        # Operandos utilizados nas operações
        self.x = 0
        self.y = 0

        # Tamanhos fixos para leitura de mensagens
        self.COMMAND_SIZE = 9   # Tamanho em bytes de um comando de operação
        self.INT_SIZE = 8       # Tamanho em bytes de um inteiro/objeto JSON

        # Identificadores de operações (com padding para 9 bytes)
        self.ADD_OP  = "+        "
        self.SUB_OP  = "-        "
        self.MULT_OP = "*        "
        self.DIV_OP  = "/        "
        self.BYE_OP  = "bye      "
        self.ROOT_OP = "**       "
        self.END_OP  = "stop     "

    # -------------------------------------------------------------------------
    # MÉTODOS DE COMUNICAÇÃO — Envio e receção de dados via socket
    # -------------------------------------------------------------------------

    def receive_str(self, connect, n_bytes: int) -> str:
        """
        Recebe uma string do socket.

        :param connect: Socket de ligação ativo.
        :param n_bytes: Número de bytes a ler.
        :return: String descodificada recebida.
        """
        data = connect.recv(n_bytes)
        return data.decode()

    def send_str(self, connect, value: str) -> None:
        """
        Envia uma string pelo socket.

        :param connect: Socket de ligação ativo.
        :param value: String a enviar.
        """
        connect.send(value.encode())

    def send_int(self, connect: socket.socket, value: int, n_bytes: int) -> None:
        """
        Envia um inteiro pelo socket em formato big-endian com sinal.

        :param connect: Socket de ligação ativo.
        :param value: Valor inteiro a enviar.
        :param n_bytes: Número de bytes a utilizar na representação.
        """
        connect.send(value.to_bytes(n_bytes, byteorder="big", signed=True))

    def receive_int(self, connect: socket.socket, n_bytes: int) -> int:
        """
        Recebe um inteiro do socket em formato big-endian com sinal.

        :param connect: Socket de ligação ativo.
        :param n_bytes: Número de bytes a ler.
        :return: Valor inteiro recebido.
        """
        data = connect.recv(n_bytes)
        return int.from_bytes(data, byteorder='big', signed=True)

    def send_object(self, connection, obj) -> None:
        """
        Serializa e envia um objeto Python como JSON pelo socket.

        O protocolo de envio é:
          1. Envia o tamanho dos dados serializados (INT_SIZE bytes).
          2. Envia os dados serializados em UTF-8.

        :param connection: Socket de ligação ativo.
        :param obj: Objeto Python serializável em JSON.
        """
        data = json.dumps(obj).encode('utf-8')
        size = len(data)
        self.send_int(connection, size, self.INT_SIZE)  # Envio do tamanho
        connection.send(data)                           # Envio do objeto

    def receive_object(self, connection):
        """
        Recebe e desserializa um objeto JSON do socket.

        O protocolo de receção é:
          1. Lê o tamanho dos dados (INT_SIZE bytes).
          2. Lê os dados e desserializa-os de JSON para Python.

        :param connection: Socket de ligação ativo.
        :return: Objeto Python desserializado.
        """
        size = self.receive_int(connection, self.INT_SIZE)  # Recebe o tamanho
        data = connection.recv(size)                        # Recebe o objeto
        return json.loads(data.decode('utf-8'))

    # -------------------------------------------------------------------------
    # MÉTODO PRINCIPAL — Ciclo de interação com o utilizador
    # -------------------------------------------------------------------------

    def execute(self):
        """
        Inicia a ligação ao servidor e entra no ciclo principal de interação.

        Apresenta um menu ao utilizador, lê a operação desejada, envia os dados
        ao servidor e exibe o resultado recebido. O ciclo termina quando o
        utilizador escolhe a opção de saída ('0') ou envia o comando de paragem.
        """
        # Criação e ligação do socket ao servidor
        connection = socket.socket()
        connection.connect((SERVER_ADDRESS, PORT))

        while True:
            print("Selecione uma das opções (+, -, *, /, **, 0 para sair):")
            opt = str(input("Opção - "))

            # --- Operação de raiz quadrada ---
            if opt == "**":
                self.send_str(connection, self.ROOT_OP)

                self.x = input("Indique o número - ")
                obj = [self.x]

                self.send_object(connection, obj)

                res = self.receive_object(connection)
                print(f"A raiz quadrada do número indicado é igual a {res[0]}")

            # --- Operações binárias e comandos de controlo ---
            else:
                # Envio do tipo de operação ao servidor
                match opt:
                    case "+":
                        self.send_str(connection, self.ADD_OP)
                    case "-":
                        self.send_str(connection, self.SUB_OP)
                    case "*":
                        self.send_str(connection, self.MULT_OP)
                    case "/":
                        self.send_str(connection, self.DIV_OP)
                    case "0":
                        # Encerra a sessão do cliente
                        opt = self.BYE_OP
                        self.send_str(connection, opt)
                        return
                    case "sys_out":
                        # Encerra o servidor remotamente
                        opt = self.END_OP
                        self.send_str(connection, opt)
                        return

                # Leitura dos dois operandos
                self.x = input("Indique o primeiro número - ")
                self.y = input("Indique o segundo número - ")

                # Envio dos operandos como objeto JSON
                obj = [self.x, self.y]
                self.send_object(connection, obj)

                # Receção e apresentação do resultado
                res = self.receive_object(connection)
                print(f"O resultado da operação é igual a {res[0]}")