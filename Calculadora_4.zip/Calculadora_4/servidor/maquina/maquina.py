import socket
import json

from servidor.operacoes import somar, subtrair, multiplicar, dividir, raiz

# =============================================================================
# CONFIGURAÇÕES DE REDE
# =============================================================================

PORT = 35000
SERVER_ADDRESS = "localhost"


# =============================================================================
# CLASSE MAQUINA — Servidor da calculadora remota
# =============================================================================

class Maquina:
    """
    Servidor de operações matemáticas acessível remotamente via socket TCP.

    Aguarda ligações de clientes, interpreta os comandos recebidos e executa
    as operações aritméticas correspondentes (adição, subtração, multiplicação,
    divisão e raiz quadrada), devolvendo os resultados ao cliente.
    """

    def __init__(self):
        """
        Inicializa o servidor com as operações disponíveis e as constantes de protocolo.

        Instancia os módulos de cada operação matemática e define os tamanhos
        de mensagem e identificadores de comandos utilizados na comunicação.
        """

        # Módulos de operações matemáticas
        self.som  = somar.Somar()
        self.sub  = subtrair.Subtrair()
        self.mult = multiplicar.Multiplicar()
        self.div  = dividir.Dividir()
        self.rai  = raiz.RaizQuadrada()

        # Tamanhos fixos para leitura de mensagens
        self.COMMAND_SIZE = 9   # Tamanho em bytes de um comando de operação
        self.INT_SIZE = 8       # Tamanho em bytes de um inteiro/objeto JSON

        # Identificadores de operações (com padding para 9 bytes)
        self.ADD_OP  = "+        "
        self.SUB_OP  = "-        "
        self.MULT_OP = "*        "
        self.DIV_OP  = "/        "
        self.ROOT_OP = "**       "
        self.BYE_OP  = "bye      "
        self.END_OP  = "stop     "

    # -------------------------------------------------------------------------
    # MÉTODOS DE COMUNICAÇÃO — Envio e receção de dados via socket
    # -------------------------------------------------------------------------

    def receive_int(self, connection, n_bytes: int) -> int:
        """
        Recebe um inteiro do socket em formato big-endian com sinal.

        :param connection: Socket de ligação ativo.
        :param n_bytes: Número de bytes a ler.
        :return: Valor inteiro recebido.
        """
        data = connection.recv(n_bytes)
        return int.from_bytes(data, byteorder='big', signed=True)

    def send_int(self, connection, value: int, n_bytes: int) -> None:
        """
        Envia um inteiro pelo socket em formato big-endian com sinal.

        :param connection: Socket de ligação ativo.
        :param value: Valor inteiro a enviar.
        :param n_bytes: Número de bytes a utilizar na representação.
        """
        connection.send(value.to_bytes(n_bytes, byteorder="big", signed=True))

    def receive_str(self, connection, n_bytes: int) -> str:
        """
        Recebe uma string do socket.

        :param connection: Socket de ligação ativo.
        :param n_bytes: Número de bytes a ler.
        :return: String descodificada recebida.
        """
        data = connection.recv(n_bytes)
        return data.decode()

    def send_str(self, connection, value: str) -> None:
        """
        Envia uma string pelo socket.

        :param connection: Socket de ligação ativo.
        :param value: String a enviar.
        """
        connection.connection.send(value.encode())

    def send_object(self, connection, obj) -> None:
        """
        Serializa e envia um objeto Python como JSON pelo socket.

        O protocolo de envio é:
          1. Envia o tamanho dos dados serializados (INT_SIZE bytes).
          2. Envia os dados serializados em UTF-8.

        :param connection: Socket de ligação ativo.
        :param obj: Objeto Python serializável em JSON.
        """
        data = json.dumps(obj).encode('utf-8')
        size = len(data)
        self.send_int(connection, size, self.INT_SIZE)  # Envio do tamanho
        connection.send(data)                           # Envio do objeto

    def receive_object(self, connection):
        """
        Recebe e desserializa um objeto JSON do socket.

        O protocolo de receção é:
          1. Lê o tamanho dos dados (INT_SIZE bytes).
          2. Lê os dados e desserializa-os de JSON para Python.

        :param connection: Socket de ligação ativo.
        :return: Objeto Python desserializado.
        """
        size = self.receive_int(connection, self.INT_SIZE)  # Recebe o tamanho
        data = connection.recv(size)                        # Recebe o objeto
        return json.loads(data.decode('utf-8'))

    # -------------------------------------------------------------------------
    # MÉTODO PRINCIPAL — Ciclo de escuta e processamento de pedidos
    # -------------------------------------------------------------------------

    def execute(self):
        """
        Inicia o servidor e entra no ciclo principal de escuta de ligações.

        Aguarda ligações de clientes, processa os pedidos de operações matemáticas
        e envia os resultados de volta. O servidor mantém-se ativo até receber
        o comando de paragem (END_OP). Para cada cliente, mantém o ciclo de
        pedidos até receber o comando de desconexão (BYE_OP).
        """
        # Criação, bind e escuta do socket do servidor
        s = socket.socket()
        s.bind(('', PORT))
        s.listen(1)

        print("Waiting for clients to connect on port " + str(PORT))

        keep_running = True
        while keep_running:
            print("On accept...")

            # Aceita nova ligação de cliente
            connection, address = s.accept()
            print("Client " + str(address) + " just connected")

            last_request = False
            while not last_request:

                # Lista para acumular o resultado da operação
                resu = []

                # Leitura do tipo de comando enviado pelo cliente
                request_type = self.receive_str(connection, self.COMMAND_SIZE)

                # --- Comando de desconexão do cliente ---
                if request_type == self.BYE_OP:
                    last_request = True
                    print("Client " + str(address) + " disconnected")

                # --- Comando de paragem do servidor ---
                elif request_type == self.END_OP:
                    last_request = True
                    keep_running = False
                    print("Server is shutting down...")

                # --- Operação de raiz quadrada ---
                elif request_type == self.ROOT_OP:
                    value = self.receive_object(connection)

                    print("Received value for root: " + str(value[0]))
                    resu.append(self.rai.execute(float(value.pop())))

                    self.send_object(connection, resu)
                    print("Sent result for root: " + str(resu))

                # --- Operações binárias (adição, subtração, multiplicação, divisão) ---
                else:
                    list_object = list(self.receive_object(connection))
                    value_1 = float(list_object[0])
                    value_2 = float(list_object[1])

                    match request_type:

                        case self.ADD_OP:
                            print("Received values for addition: " + str(value_1) + " and " + str(value_2))
                            resu.append(self.som.execute(value_1, value_2))

                            self.send_object(connection, resu)
                            print("Sent result for addition: " + str(resu))

                        case self.SUB_OP:
                            print("Received values for subtraction: " + str(value_1) + " and " + str(value_2))
                            resu.append(self.sub.execute(value_1, value_2))

                            self.send_object(connection, resu)
                            print("Sent result for subtraction: " + str(resu))

                        case self.MULT_OP:
                            print("Received values for multiplication: " + str(value_1) + " and " + str(value_2))
                            resu.append(self.mult.execute(value_1, value_2))

                            self.send_object(connection, resu)
                            print("Sent result for multiplication: " + str(resu))

                        case self.DIV_OP:
                            print("Received values for division: " + str(value_1) + " and " + str(value_2))
                            resu.append(self.div.execute(value_1, value_2))

                            self.send_object(connection, resu)
                            print("Sent result for division: " + str(resu))
